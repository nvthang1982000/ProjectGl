package com.hcl.productManagement.rep;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcl.productManagement.model.FeatureEntity;

public interface FeatureRepository extends JpaRepository<FeatureEntity, Integer >{

}
