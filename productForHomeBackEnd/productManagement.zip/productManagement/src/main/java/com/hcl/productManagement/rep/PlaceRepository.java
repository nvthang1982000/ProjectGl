package com.hcl.productManagement.rep;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcl.productManagement.model.PlaceEntity;

public interface PlaceRepository extends JpaRepository<PlaceEntity, Integer >{

}
