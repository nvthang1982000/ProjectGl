package com.hcl.productManagement.rep;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcl.productManagement.model.PlaceFeatureEntity;

public interface PlaceFeatureRepository extends JpaRepository<PlaceFeatureEntity, Integer >{
}
